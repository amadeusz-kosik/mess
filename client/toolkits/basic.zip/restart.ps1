Get-Process | Out-File C:\MESS\Results\restart.log
