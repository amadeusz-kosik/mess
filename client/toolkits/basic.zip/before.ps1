Get-Process | Out-File C:\MESS\Results\before.log
